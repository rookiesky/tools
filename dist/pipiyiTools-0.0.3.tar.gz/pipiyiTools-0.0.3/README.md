# 一个小工具合集

---

- EpubSpliter 创建 epub 电子书
- FileOperation 操作文件
- ListQueue list 队列
- Log 日志
- MyRequest 一个带随机 header 的 requests
- PooledBase 数据库操作
- Storage 基于 heapq 队列

> 编译:python3 setup.py sdist bdist_wheel
> 上传:twine upload dist/\*
